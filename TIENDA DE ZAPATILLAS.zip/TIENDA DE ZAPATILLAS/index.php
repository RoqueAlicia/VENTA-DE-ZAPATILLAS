<?php 
//redireccionar a la vista de login

header('location: vistas/login.html');
 ?>